// This program has an error
#include <iostream>
#include <vector>
#include <string>
using namespace std;
void read_input(int n, int m, vector<int> & inp, vector<string> & ar)
{
	for (int i = 0; i < n; ++i)
	{
		string a;
		cin >> a;
		ar.push_back(a);
	}

	for (int i = 0; i < n; i++)
	{
		int b;
		cin >> b;
		inp.push_back(b);
	}
}

void process(int n1, int m1, bool err, vector<int> & inp1, vector<string> & ar1 ,bool & test)
{
	test=true;
	for(int i=0;i<ar1.size()-1;i++)
	{
		if(ar1[i].size()!=ar1[i+1].size())
		{
			test=false;
		}
		if(test==false)
		{
			cout<<"Invalid Network\n";
			break;
		}
	}
	for (int j = 0; j < m1; j++)
	{
		for (int i = 0; i < n1 - 1; i++)
		{
			if (ar1[i][j] != '-')
			{
				if (ar1[i][j] < 'a' || ar1[i][j] > 'z')
				{
					cout << "Invalid Network\n";
					err = true;
				}
				if (!err)
				{
					
					for (int k = i + 1; k < n1; k++)
					{
						int cnt = 1;
						if (ar1[i][j] == ar1[k][j])
						{
							cnt++;
							if (inp1[i] > inp1[k])
							{
								int temp = inp1[i];
								inp1[i] = inp1[k];
								inp1[k] = temp;
							}
						}
						if (cnt != 2 && i==n1-1)
					    {
						  cout << "Invalid Network\n";
						  err = true;
					    }
					    else if(cnt==2)
					    {
						  break;
					    }
					}
					
				}
			}
		}

	}
}

void generate_output(int n3, bool err1, bool flag1, vector<int> & inp2)
{
	if (!err1)
	{
		for (int i = 0; i < n3 - 1; i++)
			if (inp2[i] > inp2[i + 1])
			{
				
				flag1 = true;
			}
		if (!flag1)
		{
			cout << "Sorted\n";
		}
		else
		{
			cout << "Not Sorted\n";
		}
	}
}

int main()
{
	int p, q;
	vector<string> array;
	vector<int> input;
	bool flag2 = false, err2 = false,test2=true;
	cin >> p >> q;
	read_input(p, q, input, array);
	process(p, q, err2, input, array,test2);
	if(test2==true)
	{
	  generate_output(p, err2, flag2, input);
	}  
}
