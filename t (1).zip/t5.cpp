#include<iostream>
#include <iomanip>
using namespace std;
class Time{
	private:
		int hour;
		int min;
	public:
	
		Time(int h=0  , int m=0)
		{
			hour=h;
			min=m;
		}
		void set_time(int h, int m)
		{
			hour=h;
			min=m;
		}
		void change()
		{
			int h2,m2;
			bool check=true;
			while(check)
			{
				cout<<"please enter new hour : ";
				cin>>h2;
				cout<<"please enter new minute : ";
				cin>>m2;
				if(h2>=0 && m2>=0 && m2<60 && h2<24)
				{
					hour=h2;
					min=m2;
					check=false;
				}
				else
				{
					cout<<"try again!\n";
				}
			}
		}
		int get_hour()
		{
			return hour;
		}
		int get_min()
		{
			return min;
		}
		int compare_time(int h,int m)
		{
			if(((this->hour==h) && (this->min < m)) || ((this->hour < h)))
			{
				return -1;
			}
			else if(((this->hour==h) && (this->min > m)) || ((this->hour > h)))
			{
				return 1;
			}
			else if((this->hour==h) && (this->min==m))
			{
				return 0;
			}
		}
		string time_of_day()
		{
			if(this->hour>=0 && this->hour<12)
			{
				return "morning";
			}
			else if(this->hour==12 && this->min==0)
			{
				return "noon";
			}
			else if(this->hour>=17 && this->hour<20)
			{
				return "evening";
			}
			else if(this->hour>=20 && this->hour<24)
			{
				return "night";
			}
			else
			{
				return "afternoon";
			}
		}
		void print()
		{
			cout<<((hour==0 || hour==12) ? 12 : hour % 12)<<":"<<setfill('0')<<setw(2)<<min<<(hour<12 ? " AM " : "PM");
		}
		
};
bool check_time(int h, int m)
{
	if(h>=0 && h<24 && m>=0 && m<60 )
	{
		return true; 
	}
	else
	{
		return false;
	}
}
int main()
{
	bool check=true,check2=true,check3=true;
	int choice;
	int h1,m1;
	Time t;
	while(check)
	{
		cout<<"plese enter hour : ";
	    cin>>h1;
	    cout<<"please enter minute : ";
	    cin>>m1;
	    
		if(check_time(h1,m1))
		{
			t.set_time(h1,m1);
			check=false;
		}
		else
		{
			cout<<"try again!\n";
		}
	}

	while(check2)
	{
		cout<<"plese enter your choice:\n";
		cout<<"1 : change time\n";
		cout<<"2 : compare two time:\n";
		cout<<"3 : what time of day:\n";
		cout<<"4 : print time\n";
		cout<<"5 : exit\n";
		cin>>choice;
		if(choice==1)
		{
			t.change();
		}
		else if(choice==2)
		{
			check3=true;
			while(check3)
			{
				cout<<"please enter time to compare whith the original time\n";
			    cout<<"hour :";
			    cin>>h1;
			    cout<<"minute :";
			    cin>>m1;
			    if(check_time(h1,m1))
			    {
			    	cout<<t.compare_time(h1,m1)<<endl;
			    	check3=false;
				}
				else
				{
					cout<<"try again!\n";
				}
			}
		
		}
		else if(choice==3)
		{
			cout<<t.time_of_day()<<endl;
		}
		else if(choice==4)
		{
			t.print();
			cout<<endl;
		}
		else if(choice==5)
		{
			check2=false;
		}
		else
		{
			cout<<"your choice is incorect"<<endl<<"try again\n";
		}
	}
}